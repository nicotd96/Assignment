#!/usr/bin/env python3
import sys

header_skipped = False

for line in sys.stdin:
    if not header_skipped:
        header_skipped = True
        continue  # skip the header line
    
    parts = line.strip().split(',')
    if len(parts) < 2:
        continue
    category = parts[0].strip()
    sales = parts[1].strip()
    if sales:
        print(f"{category}\t{sales}")
