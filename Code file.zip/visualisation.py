# visualisation.py
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load processed data
data = pd.read_csv("processed_retail_data.csv")

# Basic distribution plots
plt.figure(figsize=(10,5))
sns.histplot(data['age'], bins=20, kde=True)
plt.title('Customer Age Distribution')
plt.savefig("age_distribution.png")
plt.close()

# Churn vs loyalty program
plt.figure(figsize=(6,4))
sns.countplot(x='churned', hue='loyalty_program', data=data)
plt.title('Churn by Loyalty Program')
plt.savefig("churn_loyalty.png")
plt.close()

# Average purchase value by income bracket
plt.figure(figsize=(6,4))
sns.boxplot(x='income_bracket', y='avg_purchase_value', data=data)
plt.title('Average Purchase Value by Income Bracket')
plt.savefig("purchase_value_income.png")
plt.close()

print("Visualizations saved: age_distribution.png, churn_loyalty.png, purchase_value_income.png")
