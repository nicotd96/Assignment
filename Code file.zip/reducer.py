#!/usr/bin/env python3
import sys

current_category = None
total_sales = 0

for line in sys.stdin:
    category, sales = line.strip().split('\t')
    try:
        sales = float(sales)
    except ValueError:
        continue  # skip non-numeric sales

    if current_category == category:
        total_sales += sales
    else:
        if current_category:
            print(f"{current_category}\t{total_sales}")
        current_category = category
        total_sales = sales

if current_category:
    print(f"{current_category}\t{total_sales}")
