# preprocessing.py
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from datetime import datetime

# Load dataset
data = pd.read_csv("/mnt/d/assessmentdata/retail_data.csv")

# Display initial info
print("Initial data shape:", data.shape)
print(data.head())

# Handle missing values
data.fillna({
    'age': data['age'].median(),
    'income_bracket': 'Medium',
    'gender': 'Other',
    'membership_years': 0,
    'churned': 'No',
    'number_of_children': 0,
    'avg_purchase_value': 0,
    'avg_discount_used': 0
}, inplace=True)

# Encode categorical variables
categorical_cols = ['gender', 'income_bracket', 'loyalty_program', 'churned', 
                    'marital_status', 'education_level', 'occupation', 'payment_method', 
                    'store_location', 'preferred_store', 'product_category', 
                    'product_brand', 'promotion_type', 'promotion_channel', 'promotion_target_audience']

le_dict = {}
for col in categorical_cols:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col].astype(str))
    le_dict[col] = le

# Convert date columns to datetime
date_cols = ['transaction_date', 'last_purchase_date', 'product_manufacture_date', 
             'product_expiry_date', 'product_shelf_life', 'promotion_start_date', 
             'promotion_end_date']
for col in date_cols:
    data[col] = pd.to_datetime(data[col], errors='coerce')

# Feature engineering example: days since last purchase
data['days_since_last_purchase'] = (datetime.now() - data['last_purchase_date']).dt.days

# Save processed data
data.to_csv("processed_retail_data.csv", index=False)
print("Preprocessing done, saved to processed_retail_data.csv")
